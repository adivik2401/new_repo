# RSA-PSS WITHOUT ANY LIBRARIES

# ---------------- SHA-256 ----------------

K = [
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,
0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,
0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,
0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,
0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,
0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,
0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,
0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,
0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
]

H0 = [
0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19
]

MASK = 0xffffffff

def rotr(x, n):
    return ((x >> n) | (x << (32-n))) & MASK

def sha256(msg):
    h = H0[:]
    data = msg[:]
    length = len(data) * 8

    data.append(128)

    while len(data) % 64 != 56:
        data.append(0)

    for i in range(7, -1, -1):
        data.append((length >> (i*8)) & 255)

    for block in range(0, len(data), 64):
        w = []

        for i in range(16):
            j = block + i*4
            w.append(
                (data[j] << 24) |
                (data[j+1] << 16) |
                (data[j+2] << 8) |
                data[j+3]
            )

        for i in range(16, 64):
            s0 = rotr(w[i-15],7) ^ rotr(w[i-15],18) ^ (w[i-15] >> 3)
            s1 = rotr(w[i-2],17) ^ rotr(w[i-2],19) ^ (w[i-2] >> 10)
            w.append((w[i-16]+s0+w[i-7]+s1) & MASK)

        a,b,c,d,e,f,g,hh = h

        for i in range(64):
            S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25)
            ch = (e & f) ^ (~e & g)
            t1 = (hh + S1 + ch + K[i] + w[i]) & MASK

            S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22)
            maj = (a & b) ^ (a & c) ^ (b & c)
            t2 = (S0 + maj) & MASK

            hh = g
            g = f
            f = e
            e = (d+t1) & MASK
            d = c
            c = b
            b = a
            a = (t1+t2) & MASK

        h = [
            (h[0]+a)&MASK, (h[1]+b)&MASK,
            (h[2]+c)&MASK, (h[3]+d)&MASK,
            (h[4]+e)&MASK, (h[5]+f)&MASK,
            (h[6]+g)&MASK, (h[7]+hh)&MASK
        ]

    result = []

    for x in h:
        for i in range(3, -1, -1):
            result.append((x >> (i*8)) & 255)

    return result


# ---------------- MGF1 ----------------

def MGF1(seed, length):
    T = []
    counter = 0

    while len(T) < length:
        c = []

        for i in range(3, -1, -1):
            c.append((counter >> (i*8)) & 255)

        T += sha256(seed + c)
        counter += 1

    return T[:length]


# ---------------- RSA KEYS ----------------

# Fixed educational primes (not secure for real use)
p = (1 << 521) - 1
q = (1 << 607) - 1

n = p * q
phi = (p-1) * (q-1)

e = 65537
d = pow(e, -1, phi)


def to_int(data):
    x = 0

    for b in data:
        x = x*256 + b

    return x


def to_bytes(x, length):
    result = [0] * length

    for i in range(length-1, -1, -1):
        result[i] = x % 256
        x = x // 256

    return result


# ---------------- PSS ENCODING ----------------

def encode(message, salt):
    emBits = n.bit_length() - 1
    emLen = (emBits+7)//8

    mHash = sha256(message)
    h = sha256([0]*8 + mHash + salt)

    dbLen = emLen - 32 - 1
    psLen = dbLen - len(salt) - 1

    DB = [0]*psLen + [1] + salt

    mask = MGF1(h, dbLen)

    maskedDB = []

    for a,b in zip(DB,mask):
        maskedDB.append(a ^ b)

    unused = 8*emLen - emBits
    maskedDB[0] &= 255 >> unused

    return maskedDB + h + [188]


# ---------------- SIGN ----------------

def sign(message, salt):
    EM = encode(message, salt)
    m = to_int(EM)
    return pow(m, d, n)


# ---------------- VERIFY ----------------

def verify(message, signature):
    emBits = n.bit_length() - 1
    emLen = (emBits+7)//8

    if signature < 0 or signature >= n:
        return False

    m = pow(signature, e, n)
    EM = to_bytes(m, emLen)

    if EM[-1] != 188:
        return False

    maskedDB = EM[:emLen-33]
    h = EM[emLen-33:emLen-1]

    unused = 8*emLen - emBits

    if maskedDB[0] >> (8-unused) != 0:
        return False

    mask = MGF1(h, len(maskedDB))

    DB = []

    for a,b in zip(maskedDB,mask):
        DB.append(a ^ b)

    DB[0] &= 255 >> unused

    psLen = len(DB) - 16 - 1

    if DB[:psLen] != [0]*psLen:
        return False

    if DB[psLen] != 1:
        return False

    salt = DB[psLen+1:]

    mHash = sha256(message)
    h2 = sha256([0]*8 + mHash + salt)

    return h == h2


# ---------------- MAIN ----------------

message = input("Enter message: ")
salt_text = input("Enter 16-character salt: ")

if len(salt_text) != 16:
    print("Salt must contain exactly 16 characters")
else:
    msg = [ord(ch) for ch in message]
    salt = [ord(ch) for ch in salt_text]

    signature = sign(msg, salt)

    print("\\nRSA-PSS Signature:")
    print(signature)

    print("\\nVerification:", verify(msg, signature))

    changed = [ord(ch) for ch in message + "X"]
    print("Modified message verification:", verify(changed, signature))
