import numpy as np

def columnar_encrypt(text, key):
    text = text.upper().replace(" ", "")
    key = key.upper()
    n = len(key)

    while len(text) % n != 0:
        text += "X"

    rows = len(text) // n
    matrix = np.empty((rows, n), dtype=str)

    k = 0
    for i in range(rows):
        for j in range(n):
            matrix[i][j] = text[k]
            k += 1

    order = sorted(range(n), key=lambda i: key[i])

    cipher = ""
    for column in order:
        for j in range(rows):
            cipher += matrix[j][column]

    return cipher


def columnar_decrypt(cipher, key):
    key = key.upper()
    n = len(key)
    rows = len(cipher) // n

    matrix = np.empty((rows, n), dtype=str)
    order = sorted(range(n), key=lambda i: key[i])

    k = 0
    for column in order:
        for j in range(rows):
            matrix[j][column] = cipher[k]
            k += 1

    text = ""
    for i in range(rows):
        for j in range(n):
            text += matrix[i][j]

    return text.rstrip("X")


text = "ATTACKATDAWN"
key = "4312"

cipher = columnar_encrypt(text, key)
print("Encrypted:", cipher)
print("Decrypted:", columnar_decrypt(cipher, key))
