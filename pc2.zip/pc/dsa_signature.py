import hashlib

# Small values for learning only
p = 23
q = 11
g = 4
x = 3                       # private key
y = pow(g, x, p)            # public key


def sign(message):
    h = int(hashlib.sha256(message.encode()).hexdigest(), 16) % q
    k = 7                   # must be secret and relatively prime to q
    r = pow(g, k, p) % q
    s = (pow(k, -1, q) * (h + x * r)) % q
    return r, s


def verify(message, signature):
    r, s = signature
    if not (0 < r < q and 0 < s < q):
        return False

    h = int(hashlib.sha256(message.encode()).hexdigest(), 16) % q
    w = pow(s, -1, q)
    u1 = (h * w) % q
    u2 = (r * w) % q
    v = ((pow(g, u1, p) * pow(y, u2, p)) % p) % q
    return v == r


message = "HELLO WORLD"
sig = sign(message)
print("Signature:", sig)
print("Verified:", verify(message, sig))
print("Wrong message:", verify("HELLO", sig))
