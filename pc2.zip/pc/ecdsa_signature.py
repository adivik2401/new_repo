import hashlib

# Small curve: y^2 = x^3 + 2x + 2 (mod 17)
p = 17
a = 2
b = 2
G = (5, 1)
n = 19                      # order of G
private = 7
d = private
public = None


def add(P, Q):
    if P is None:
        return Q
    if Q is None:
        return P
    x1, y1 = P
    x2, y2 = Q

    if x1 == x2 and (y1 + y2) % p == 0:
        return None

    if P == Q:
        m = ((3 * x1 * x1 + a) * pow(2 * y1, -1, p)) % p
    else:
        m = ((y2 - y1) * pow(x2 - x1, -1, p)) % p

    x3 = (m * m - x1 - x2) % p
    y3 = (m * (x1 - x3) - y1) % p
    return x3, y3


def multiply(k, P):
    R = None
    while k > 0:
        if k % 2 == 1:
            R = add(R, P)
        P = add(P, P)
        k //= 2
    return R


public = multiply(private, G)


def sign(message):
    h = int(hashlib.sha256(message.encode()).hexdigest(), 16) % n
    k = 3                   # must be secret and never reused in real ECDSA
    point = multiply(k, G)
    r = point[0] % n
    s = (pow(k, -1, n) * (h + private * r)) % n
    return r, s


def verify(message, signature):
    r, s = signature
    if not (0 < r < n and 0 < s < n):
        return False

    h = int(hashlib.sha256(message.encode()).hexdigest(), 16) % n
    w = pow(s, -1, n)
    u1 = (h * w) % n
    u2 = (r * w) % n
    point = add(multiply(u1, G), multiply(u2, public))
    return point is not None and point[0] % n == r


message = "HELLO WORLD"
sig = sign(message)
print("Signature:", sig)
print("Verified:", verify(message, sig))
print("Wrong message:", verify("HELLO", sig))
