import hashlib
import os

# Educational RSA-PSS example (SHA-256)
p = 2**521 - 1
q = 2**607 - 1
n = p * q
phi = (p - 1) * (q - 1)
e = 65537
d = pow(e, -1, phi)


def mgf1(seed, length):
    mask = b""
    for i in range((length + 31) // 32):
        mask += hashlib.sha256(seed + i.to_bytes(4, "big")).digest()
    return mask[:length]


def sign(message):
    m_hash = hashlib.sha256(message.encode()).digest()
    salt = os.urandom(16)
    h = hashlib.sha256(b"\x00" * 8 + m_hash + salt).digest()

    em_bits = n.bit_length() - 1
    em_len = (em_bits + 7) // 8
    db_len = em_len - 32 - 1
    ps = b"\x00" * (db_len - len(salt) - 1)
    db = ps + b"\x01" + salt
    mask = mgf1(h, db_len)
    masked_db = bytes(a ^ b for a, b in zip(db, mask))

    unused = 8 * em_len - em_bits
    masked_db = bytes([masked_db[0] & (255 >> unused)]) + masked_db[1:]
    em = masked_db + h + b"\xbc"
    signature = pow(int.from_bytes(em, "big"), d, n)
    return signature


def verify(message, signature):
    em_bits = n.bit_length() - 1
    em_len = (em_bits + 7) // 8
    em = pow(signature, e, n).to_bytes(em_len, "big")

    if em[-1] != 0xbc:
        return False

    db_len = em_len - 32 - 1
    masked_db = em[:db_len]
    h = em[db_len:-1]
    unused = 8 * em_len - em_bits

    if masked_db[0] >> (8 - unused) != 0 if unused else False:
        return False

    mask = mgf1(h, db_len)
    db = bytes(a ^ b for a, b in zip(masked_db, mask))
    if unused:
        db = bytes([db[0] & (255 >> unused)]) + db[1:]

    salt_len = 16
    ps_len = db_len - salt_len - 1
    if db[:ps_len] != b"\x00" * ps_len or db[ps_len] != 1:
        return False
    salt = db[-salt_len:]

    m_hash = hashlib.sha256(message.encode()).digest()
    expected = hashlib.sha256(b"\x00" * 8 + m_hash + salt).digest()
    return h == expected


message = "HELLO WORLD"
signature = sign(message)
print("Signature:", signature)
print("Verified:", verify(message, signature))
print("Wrong message:", verify("HELLO", signature))
