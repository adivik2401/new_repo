import hashlib

# Small values for learning only
p = 23
g = 5
x = 6                       # private key
y = pow(g, x, p)            # public key


def sign(message):
    h = int(hashlib.sha256(message.encode()).hexdigest(), 16) % (p - 1)
    k = 7                   # must be secret and coprime to p-1
    r = pow(g, k, p)
    s = (pow(k, -1, p - 1) * (h - x * r)) % (p - 1)
    return r, s


def verify(message, signature):
    r, s = signature
    if not (0 < r < p and 0 <= s < p - 1):
        return False

    h = int(hashlib.sha256(message.encode()).hexdigest(), 16) % (p - 1)
    left = pow(g, h, p)
    right = (pow(y, r, p) * pow(r, s, p)) % p
    return left == right


message = "HELLO WORLD"
sig = sign(message)
print("Signature:", sig)
print("Verified:", verify(message, sig))
print("Wrong message:", verify("HELLO", sig))
