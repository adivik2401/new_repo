Alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
def clean(x):
    out=""
    for ch in x.upper():
        if ch.isalpha():
            out+=ch
    return out
def caeas(x,key):
    r="" #USE RESULT =""
    for ch in text:
        num=Alpha.index(ch)
        v=(key+num)%26 # IMPORTANT MOD 26
        r+=A[v]
def mono_alphabetic(text,key):
    result=""
    for ch in text.upper():
        n=Alpha.index(ch)
        r+=key[ch]
    return r
def mo_dec(text,key):
    reuslr=""
    for ch in text:
        s=key.index(ch)
        r+=Alpha[s]

def push(a,b):
    result=b
    for i in range(len(a)-len(b)):
        result+=b[i%len(b)] #replace a[i] for auto key pt
    return result
def vigene(p,vig_key,mode):
    b=""
    if len(vig_key)<len(p):
        b=push(p,vig_key)
    result=""
    for ch,bh in zip(p,b):
        i1=Alpha.index(ch)        
        i2=Alpha.index(bh)
        v=(i1+mode*i2+26)%26

        c=Alpha[v]
        result+=c
    return result
print(vigene("R","LEMON",-1))

def make_matrix(key):
    s=""
    matrix=[]
    key=key.upper().replace("I","J")
    Alpha = "ABCDEFGHJKLMNOPQRSTUVWXYZ"
    for ch in key + Alpha:
        if ch not in s:
            s+=ch
    for i in range(0,25,5):
        matrix.append(list(s[i:i+5]))

    #replce this part with matrix = np.array(list(s)).reshape(5, 5)
    return matrix
   
def make_pairs(text):
    text=text.upper().replace("I","J").replace(" ","")
    pairs=[]
    i=0
    while i< len(text):
        a=text[i]
        if i+1 ==len(text) : # end and same text same condition push x not next alph
            b="X"
            i+=1
        elif text[i]==text[i+1]:
            b="X"
            i+=1
        else:
            b=text[i+1]
            i+=2 #skip by 2
        pairs.append(a+b)
    return pairs
def playfair(text,key,mode):
    
    matrix=make_matrix(key)
    if mode==1:
        pairs=make_pairs(text)
    else:
        pairs=[text[i:i+2] for i in range(0,len(text),2)]
    result=""
    for pair in pairs:
        a,b = pair
        for r in range(5):
            for c in range(5):
                if matrix[r][c]==a:
                    r1,c1=r,c
                if matrix[r][c]==b:
                    r2,c2=r,c
        if r1== r2:
            result+=matrix[r1][(c1+mode)%5]
            result+=matrix[r2][(c2+mode)%5]
        elif c1 == c2:
            result+=matrix[(r1+mode)%5][c1%5]
            result+=matrix[(r2+mode)%5][c2%5]
        else:
            result+=matrix[r1][c2]
            result+=matrix[r2][c1]
    return result

def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a


def hill(text, key, mode):
    text = text.upper().replace(" ", "")

    if mode == 1:
        k = key

    else:
        det = (key[0][0]*key[1][1] - key[0][1]*key[1][0]) % 26

        if gcd(det, 26) != 1:
            return "Inverse does not exist"

        det_inv = pow(det, -1, 26)

        adj = [
            [key[1][1], -key[0][1]],
            [-key[1][0], key[0][0]]
        ]

        k = [
            [(det_inv * adj[0][0]) % 26, (det_inv * adj[0][1]) % 26],
            [(det_inv * adj[1][0]) % 26, (det_inv * adj[1][1]) % 26]
        ]

    if len(text) % 2 != 0:
        text += "X"

    result = ""

    for i in range(0, len(text), 2):
        x = Alpha.index(text[i])
        y = Alpha.index(text[i+1])

        result += Alpha[(k[0][0]*x + k[0][1]*y) % 26]
        result += Alpha[(k[1][0]*x + k[1][1]*y) % 26]

    return result


def vernam(text,key):# here the text, key are letters
    result=""
    for t, k in zip(text,key):
        c= ord(t)^ord(k)
        result+=chr(c)
    return result
#ord conevert a => unicode and chr converts back to letter
print(vernam("hello","byebe"))

def vernam2(text,key):
    result=""
    for t, k in zip(text,key):
        result+=str(int(t)^int(k))

        
    return result
print(vernam2("10110010","11001010"))

def rail(text,key,mode): #encryption
    if key==1:
        return text
    if mode==1:
        rails= [""]*key
        row=0
        direction = 1
        for ch in text:
            rails[row]+=ch
            if row == 0:
                direction = 1
            elif row == key-1:
                direction = -1
            row +=direction
        return "".join(rails) #remmeber htis lien is very impo
    else:
        rows = len(text) // n
        matrix = [[""] * n for i in range(rows)]

        order = sorted(range(n), key=lambda i: key[i])

        pos = 0
        for col in order:
            for row in range(rows):
                matrix[row][col] = text[pos]
                pos += 1

        result = ""
        for row in matrix:
            for ch in row:
                result += ch

        return result   
def columnar(text,key):
    text=text.upper().replace(" ","")
    key=key.upper()
    n=len(key)
    while len(text) % n!=0: # padding if not div by n
        text+="X"
    matrix=np.array(list(text)).reshape(-1,n) #automatic reagre of row =-1 but set col=n
    order=sorted(range(n),key=lamda i:key[i])
    for column in order:
        cipher+="".join(matrix[:,column])

    
    return cipher

def column(tetx):
    n=len(key)
    matrix=(list(text)).reshape(-1,n)
    order=(range(n),key=lambda i:key[i])
    for col in order:
        cipher+="".join(matrix[:col])


def rail(text):
    rails=[""]*keys
    for t in text:
        rails[row]+=t
        if row==0:
            dir=1
        elif row == len(text)-1:
            dir=-1
        row+=dir
    
    return "".join(rails)


def vername(text,key,mode):
    
    if mode==0:# ascii
        c=""
        for i in range(len(text)):
            c+=chr(ord(k[i])^ord(text[i]))
    if mode==1: #bin
        C=bin(int(k,2)^int(text,2))[2:] #FULL not char wise
    if mode ==2:
        C=hex(int(msg,16)^int(key,16))[2:] # 2 as wwedont ened the 0b at the start.
        


        
