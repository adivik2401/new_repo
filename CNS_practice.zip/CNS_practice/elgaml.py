import numpy as np 
def extend(a,b):
    s1 = 1
    s2=0 
    t1 = 0 
    t2= 1
    while b!=0:
        q = a//b 
        r = a%b 
        t = t1-q*t2 
        s = s1-q*s2
        a,b = b,r  
        t1,t2 = t2,t 
        s1,s2 = s2,s 
    return (a,s1,t1)

def compute_key(p,g,x):
    y = pow(g,x,p)
    return (p,g,y),x 

def encry(public,m):
    p,g,y = public
    k = np.random.randint(2,1008)
    c1 = pow(g,k,p)
    s= pow(y,k,p)
    c2= (m*s)%p
    return (c1,c2)
def decrpy(public,private,c1,c2):
    p,g,y = public
    x = private
    s = pow(c1,x,p)
    pp,t1,s1 = extend(s,p)
    m = (c2*t1)%p 
    return m 
msg = "HELLO"
cipher = [encry(public,ord(ch)) for ch in msg]
plain = ""
for ch in cipher:
    plain+=chr(decrpy())
p = 1009
g = 2 
x = 1005
m = np.random.randint(0,p-1)
print(m)
public,private = compute_key(p,g,x)
cipher = encry(public,m)
print(cipher)
decpr = decrpy(public,private,cipher[0],cipher[1])
print(decpr)
