
Alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
UID = "2024300020"
plaintext= "Attack at dawn"
# caesar_key = 3 
# mono_key = "QWERTYUIOPASDFGHJKLZXCVBNM"
# vig_key      = "LEMON"
# playfair_key = "MONARCHY"
# hill_key     = [3, 3, 2, 5]        

def clean(text):
    out = ""
    for ch in text.upper():
        if ch.isalpha():
            out+=ch
    return out 

def caesar(text,key):
    #use -key for decrpytion
    result = ""
    for ch in text:
        num=Alpha.index(ch) #helps to conv the letter to num 
        vali = (num+key)%26 
        chari = Alpha[vali]
        result+=chari 
    return result 

def monoalphabetic_encr(text,key):
    result = ""
    for ch in text.upper():
        indexi = Alpha.index(ch)
        result+=key[indexi]
    return result

def monoalphabetic_decrp(text,key):
    result = ""
    for ch in text.upper():
        indexi = key.index(ch)
        result+=Alpha[indexi]
    return result
def vigenere(p,vig_key,mode):
    #here mod = 1 means encrpyt and mode = -1 means decrypt 
    result = ""
    j=0
    leni = len(vig_key)
    for i in range(len(p)):
        curr = p[i]
        curr2 = vig_key[j]
        j = (j+1)%leni
        l1 = Alpha.index(curr)
        l2 = Alpha.index(curr2)
        l3 = (l1+(mode*l2)+26)%26
        curr3 = Alpha[l3] 
        result+=curr3
    return result

#playfair - diffiuclt lof of thigns to do 
def make_matrix(key):
    matrix=""
    for ch in key + Alpha:
        if ch =="J":
            ch="I"
        if ch not in matrix:
            matrix+=ch 
    return matrix 
def make_pairs(text):
    text = text.replace("J","I")
    pairs = []
    i= 0
    while i < len(text)-1:
        a = text[i]
        if text[i]!=text[i+1]:
            pairs.append([text[i],text[i+1]])
            i = i+2 
        else:
            pairs.append([text[i],'X'])
            i = i + 1 
    if(i==len(text)-1):
        pairs.append([text[i],'X'])
    return pairs
def playfair(text,key,mode):
    matrix = make_matrix(key)
    result = ""
    if(mode==1):
        for ch1,ch2 in make_pairs(text):
            r1, c1 = divmod(matrix.index(ch1), 5)   # row, column
            r2, c2 = divmod(matrix.index(ch2), 5)
            # c1,r1=matrix.index(ch1)%5,matrix.index(ch1)//5
            # c2,r2 = matrix.index(ch2)%5,matrix.index(ch2)//5
            if(r1==r2):
                c1 = (c1+1)%5
                c2 = (c2+1)%5
            elif(c1==c2):
                r1 = (r1+1)%5 
                r2 = (r2+1)%5 
            else:
                temp = c1
                c1 = c2 
                c2= temp 
            result+=matrix[r1*5+c1]+matrix[r2*5+c2]
    else:
        pairi =[]
        i =0
        while i<len(text)-1:
            pairi.append([text[i],text[i+1]])
            i = i+2 
        for i in range(len(pairi)):
                ch1 = pairi[i][0]
                ch2 = pairi[i][1]
                r1, c1 = divmod(matrix.index(ch1), 5)   # row, column
                r2, c2 = divmod(matrix.index(ch2), 5)
                    # c1,r1=matrix.index(ch1)%5,matrix.index(ch1)//5
                    # c2,r2 = matrix.index(ch2)%5,matrix.index(ch2)//5
                if(r1==r2):
                    c1 = (c1-1+5)%5
                    c2 = (c2-1+5)%5
                elif(c1==c2):
                    r1 = (r1-1+5)%5 
                    r2 = (r2-1+5)%5 
                else:
                    temp = c1
                    c1 = c2 
                    c2= temp 
                result+=matrix[r1*5+c1]+matrix[r2*5+c2]
    return result 

def gcd(a,b):
    while b:
        a,b = b,a%b 
    return a
def hill_inverse(k):
    det = (k[0]*k[3]-k[2]*k[1])
    if gcd(det,26)!=1:
        print("Hill key not invertible mod 26 (gcd(det,26) != 1)")
    else:
        #FIRST WE GO AND FIND INVERSE
        di=0
        for i in range(26):
            if (det*i)%26==1:
                di=i 
        return [(di * k[3]) % 26, (-di * k[1]) % 26,(-di * k[2]) % 26, (di * k[0]) % 26]
def hill(text, k):                            # decrypt: pass hill_inverse(k)
    if len(text) % 2 == 1:
        text += "X"                           # pad if odd length
    result = ""
    for i in range(0, len(text), 2):
        x = Alpha.index(text[i])
        y = Alpha.index(text[i + 1])
        result += Alpha[(k[0] * x + k[1] * y) % 26]
        result += Alpha[(k[2] * x + k[3] * y) % 26]
    return result

#TO get the key 
def gen_keys(uid):
    #Ceaser key
    ckey = (sum(int(d) for d in uid) % 25) + 1
    #Monoalphabetic key
    random.seed(int(uid))
    letters = list(Alpha)
    random.shuffle(letters)
    mkey= "".join(letters)

    #vignere key 
    for i in range(len(UID)):
        l1 = int(UID[i:i+1])
        l1 = l1%26
        vkey+=A[l1]
        # l2 = int(UID[i+1])
    #playfair 
    pkey = ""                                              # Playfair: same keyword, repeats removed
    for ch in vkey:
        if ch not in pkey:
            pkey += ch
    #hill 
    k = [[20,24],[5 ,1]]


p = clean(plaintext)
print("Plaintext:", p)

c = caesar(p, caesar_key)
print("\nCaesar     :", c, "->", caesar(c, -caesar_key))

c = monoalphabetic_encr(p, mono_key)
print("Mono       :", c, "->", monoalphabetic_decrp(c, mono_key))

c = vigenere(p, vig_key, 1)
print("Vigenere   :", c, "->", vigenere(c, vig_key, -1))

c = playfair(p, playfair_key, 1)
print("Playfair   :", c, "->", playfair(c, playfair_key, -1))

c = hill(p, hill_key)
print("Hill       :", c, "->", hill(c, hill_inverse(hill_key)))