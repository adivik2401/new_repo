def fermat(a,n):
    if pow(a,n-1,n) == 1:
        return "prob prime"
    else:
        return "compposite"
def euler_prim(a,n):
    r = pow(a,(n-1)//2,n)

    if r == 1 or r == n-1:
        return "prob prime"
    else:
        return "composite"
def miller_rabin(n,a):
    k=0
    q=n-1
    while q%2==0:
        q//=2
        k+=1
    x=pow(a,q,n)
    if x==1 or x==n-1:
        return "prob prime"
    
    for i in range(k-1):
        x=pow(x,2,n)
        if x == n-1:
            return "prob prime"
        elif x == 1:
            return "composite"
    return "composite"
print(miller_rabin(561,2))