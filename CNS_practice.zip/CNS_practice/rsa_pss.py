import hashlib
import random

def prime(n):
    if n<2:
        return False
    for i in range(2,n):
        if n% i ==0:
            return False
    return True
def gen_prime():
    while True:
        x= random.randrange(100000,200000)
        if prime(x):
            return x

p=gen_prime()
q=gen_prime()

while p ==q :
    q=gen_prime()
n=p*q
phi=(p-1)*(q-1)
e=65537
d=pow(e,-1,phi)

def H(data):
    return hashlib.sha256(data).digest()
def mgf(seed,length):
    T=b""
    counter= 0
    while len(T)<length:
        T+=H(seed+counter.to_bytes(4,"big"))
        counter+=1
    return T[:length]
def xor_bytes(a,b):
    return  bytes(x^y for x,y in zip(a,b))
def sign(message):
    message=message.encode()
    Hlen=32
    slen=8
    embits=n.bit_length()-1
    emLen=(embits+7)//8

    salt=ranodme.randbytes(slen)
    db=

    h=H(b"\x00"*8+mHash+salt)

    EM=maskedDB+h+b"\xbc"
    
    sig=pow(int.from_bytes(EM,"big"),d,n)