import random
def gen_public(g, priv,p):
    return pow(g,priv,p)
def gen_key(pub,priv,p):
    return pow(pub, priv,p)
p=29
g=4

a=random.randint(2,p-2) #gen random int b/w 2 to p-2
b=random.randint(2,p-2)
A=gen_public(g,a,p)
B=gen_public(g,b,p)

K_alice=gen_key(B,a,p)
K_bob=gen_key(A,b,p)
print("p, g      :", p, g)
print("Alice priv:", a, " public A:", A)
print("Bob priv  :", b, " public B:", B)
print("Alice key :", K_alice)
print("Bob key   :", K_bob)
print("Match     :", K_alice == K_bob)