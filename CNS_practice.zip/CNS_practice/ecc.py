import random

def extended_euclid(a, b):
    old_r, r = a, b
    old_x, x = 1, 0
    while r != 0:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_x, x = x, old_x - q * x
    return old_r, old_x

def inv(a, p):
    g, x = extended_euclid(a % p, p)
    return x % p

def point_add(P, Q, a, p):
    if P is None: return Q
    if Q is None: return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2 and (y1 + y2) % p == 0:
        return None                      # P + (-P) = O
    if P == Q:
        lam = (3 * x1 * x1 + a) * inv(2 * y1, p) % p
    else:
        lam = (y2 - y1) * inv(x2 - x1, p) % p
    x3 = (lam * lam - x1 - x2) % p
    y3 = (lam * (x1 - x3) - y1) % p
    return (x3, y3)

def point_neg(P, p):
    if P is None:                        # -O = O
        return None
    x, y = P
    return (x, (-y) % p)

def scalar(k, P, a, p):
    Q = P
    for i in range(k - 1):
        Q = point_add(Q, P, a, p)
    return Q

def ecdh(G, n, a, p):
    pa = random.randint(2, n - 1)        # Alice private
    pb = random.randint(2, n - 1)        # Bob private
    A = scalar(pa, G, a, p)              # Alice public
    B = scalar(pb, G, a, p)              # Bob public
    KA = scalar(pa, B, a, p)             # Alice's shared key
    KB = scalar(pb, A, a, p)             # Bob's shared key
    return pa, A, pb, B, KA, KB

def ec_encrypt(M, Q, G, n, a, p):
    k = random.randint(2, n - 1)
    C1 = scalar(k, G, a, p)                          # C1 = k*G
    C2 = point_add(M, scalar(k, Q, a, p), a, p)      # C2 = M + k*Q
    return C1, C2

def ec_decrypt(C1, C2, d, a, p):
    S = scalar(d, C1, a, p)                          # S = d*C1
    return point_add(C2, point_neg(S, p), a, p)      # M = C2 - S


# ---- curve parameters ----
p, a, b = 17, 2, 2
G = (5, 1)
n = 19                                   # order of G

print("2G  =", scalar(2, G, a, p))
print("3G  =", scalar(3, G, a, p))
print("4G  =", scalar(4, G, a, p))
print("19G =", scalar(19, G, a, p))

# ---- ECDH ----
pa, A, pb, B, KA, KB = ecdh(G, n, a, p)
print("\nECDH")
print("Alice priv:", pa, " pub:", A)
print("Bob priv  :", pb, " pub:", B)
print("Alice key :", KA)
print("Bob key   :", KB)
print("Match     :", KA == KB)

# ---- ECC ElGamal (message is a point) ----
d = random.randint(2, n - 1)             # receiver private
Q = scalar(d, G, a, p)                   # receiver public
M = scalar(7, G, a, p)                   # pretend this point is the message
C1, C2 = ec_encrypt(M, Q, G, n, a, p)
dec = ec_decrypt(C1, C2, d, a, p)
print("\nECC ElGamal")
print("Message point:", M)
print("Ciphertext   :", C1, C2)
print("Decrypted    :", dec)
print("Match        :", dec == M)