
import numpy as np

def vernam(p, k, mode, operation):

    if mode == "ascii":
        P = np.frombuffer(p.encode(), dtype=np.uint8)
        K = np.frombuffer(k.encode(), dtype=np.uint8)

    elif mode == "binary":
        P = np.array([int(x) for x in p], dtype=np.uint8)
        K = np.array([int(x) for x in k], dtype=np.uint8)

    elif mode == "hex":
        P = np.frombuffer(bytes.fromhex(p), dtype=np.uint8)
        K = np.frombuffer(bytes.fromhex(k), dtype=np.uint8)

    else:
        print("Invalid mode")
        return

    if len(P) != len(K):
        print("Key and plaintext lengths must match")
        return

    if mode == "binary" and (
        any(x not in '01' for x in p + k)
    ):
        print("Invalid binary input")
        return

    if operation == "encrypt":
        C = np.bitwise_xor(P, K)

    elif operation == "decrypt":
        C = np.bitwise_xor(P, K)

    else:
        print("Invalid operation")
        return

    if mode == "ascii":
        print("Result (Hex):", C.tobytes().hex())
        if operation == "encrypt":
            print("Decrypted:", np.bitwise_xor(C, K).tobytes().decode())

    elif mode == "binary":
        print("Result:", ''.join(map(str, C)))
        if operation == "encrypt":
            print("Decrypted:", ''.join(map(str, np.bitwise_xor(C, K))))

    elif mode == "hex":
        print("Result:", C.tobytes().hex())
        if operation == "encrypt":
            print("Decrypted:", np.bitwise_xor(C, K).tobytes().hex())


mode = input("Enter mode (ascii/binary/hex): ").lower()
operation = input("Enter operation (encrypt/decrypt): ").lower()

p = input("Enter plaintext/ciphertext: ")
k = input("Enter key: ")

vernam(p, k, mode, operation)
