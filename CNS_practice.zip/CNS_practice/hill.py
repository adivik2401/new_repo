import numpy as np

Alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
def gen_matrix(key):
    a=[]
    for ch in key.upper():
        a.append(Alpha.index(ch))
    return np.array(a).reshape(3,3)
def hill(pt,key,mode):
    key=gen_matrix(key)
    result=""

    for i in range(0,len(pt),3):
        p=np.array([[Alpha.index(pt[i])],[Alpha.index(pt[i+1])],[Alpha.index(pt[i+2])]])
        if mode == 1:
            c= np.dot(key,p) %26
        else:
            det=np.linalg.det(key) %26
            d=pow(det,-1,26)
            adj=np.linalg.inv(key)*np.linalg.det(key)
            inv=(d*adj) % 26
            c= np.dot(inv,p)%26
        for j in range(3):
            result+=Alpha[int(c[j][0])]
    return result