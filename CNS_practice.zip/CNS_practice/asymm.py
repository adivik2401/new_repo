import random
#Diffie Hellman
def gen_public(g, priv,p):
    return pow(g,priv,p)
def gen_key(pub,priv,p):
    return pow(pub, priv,p)
p=29
g=4

a=random.randint(2,p-2) #gen random int b/w 2 to p-2
b=random.randint(2,p-2)
A=gen_public(g,a,p)
B=gen_public(g,b,p)

K_alice=gen_key(B,a,p)
K_bob=gen_key(A,b,p)
print("p, g      :", p, g)
print("Alice priv:", a, " public A:", A)
print("Bob priv  :", b, " public B:", B)
print("Alice key :", K_alice)
print("Bob key   :", K_bob)
print("Match     :", K_alice == K_bob)

#RSA

def gcd(a,b):
    while b:
        a,b =b, a%b
    return a
def rsa_enc(m,e,n):
    return pow(m,e,n)
def rsa_dec(c,d,n):
    return pow(c,d,n)
p=3
q=11
n=p*q
phi=(p-1)*(q-1)

e=7
for i in range(2,phi):
    if gcd(i, phi) == 1:
        d = pow(e,-1,phi)
        break
print("Public Key :", e, n)
print("Private Key:", d, n)

m = 5

c = rsa_enc(m, e, n)
print("Encrypted:", c)

decrypted = rsa_dec(c, d, n)
print("Decrypted:", decrypted)

#ELGAMAL

def gen_pub(g,x,p):
    return pow(g,x,p)
def encrypt(m,y,g,p):
    k=random.randint(2,p-2)
    c1=pow(g,k,p)
    c2=(m*pow(y,k,p) ) % p #c2 is indep of c1 its m.shared_key % p
    return c1,c2
def dec(c1,c2,x,p):
    k=pow(c1,x,p)
    m=(c2*pow(k,-1,p) )% p # never do k^-1 that wrong its k,-1,p alwasy use pow .
    return m
p = 23
g = 5

x = 6
y = gen_public(g, x, p)

m = int(input("Enter plaintext number: "))

c1, c2 = encrypt(m, y, g, p)

print("Public Key:", y)
print("Ciphertext:", c1, c2)

d = dec(c1, c2, x, p)
print("Decrypted:", d)

def add(P, Q, a, p):
    if P is None:
        return Q
    if Q is None:
        return P

    x1, y1 = P
    x2, y2 = Q

    if x1 == x2 and (y1+y2) % p == 0:
        return None

    if P == Q:
        m = ((3*x1*x1+a)*pow(2*y1,-1,p)) % p
    else:
        m = ((y2-y1)*pow(x2-x1,-1,p)) % p

    x3 = (m*m-x1-x2) % p
    y3 = (m*(x1-x3)-y1) % p

    return (x3,y3)

def add(P,Q,a,p):
    xq,y1=P
    x2,y2=Q
    if x1==x2 and y1+y2%P==0:
        retru None
    if P==Q:
        m=pow(2*y1,-1,p)*(3*x1*x1+a)
    else:
        m=y2-y1 *pow(x2-x1,-1,p)
    x3=(m*m -x1-x2)% p
    y3=(m*(x1-x3)-y1)%p
    return (x3,y3)
def ecc(k,G,a,p): #G is the gen pt know to all G,a,p know to all
    R=None #pt at inf identiyt elemtn ts for 0 addiotin
    while k>0:
        if k%2 == 1: #bin rep  only when 1 cms we add to R
            R= add(R,G,a,p)
        G=add(G,G,a,p) #always douyble G
        k //=2 #this is to stop 
    return R

def encyrpt(M,Q,G,k,a,p):
    c1=ecc(k,G,a,p)
    c2=add(M,ecc(K,Q,a,p),a,p)
    return c1,c2

def decyrpt(c1,c2,d,a,p):
    S=ecc(d,c1,a,p) #s1= dC1
    if S is None: #is S is ide subt the Key s1 doesnt make any diff
        return C2
    S=(S[0],(-S[1])%p)# -S=(x,-ymodp)//reflect over x axis
    M=add(c2,S,a,p) #DO M= c2-S
    return M

p = 17
a = 2
b = 2
G = (5, 1)

alice = 5
bob = 7
A = ecc(alice, G, a, p)
B = ecc(bob, G, a, p)

K1 = ecc(alice, B, a, p)
K2 = ecc(bob, A, a, p)

print("Alice Public Key:", A)
print("Bob Public Key:", B)
print("Alice Shared Key:", K1)
print("Bob Shared Key:", K2)