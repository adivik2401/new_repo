def gcd(a,b):
    while b!=0:
        a,b=b,a%b
def ex_eu(a,b):
    t1=0,t2=1
    s1=1,s2=0
    while b!=0:
        q=a//b
        a,b=b,a%b
        s1,s2=s2, s1-q*s2
        t1,t2=t2, t1-q*t2
        
    if t1<0:
        return t1+26
    else:
        return t1
def fermat(a,n):
    if pow(a,n-1,n)==1:
        prob 

    elsE:
        com
def miller(a,n):
    q=n-1
    k=0
    while q%2==0:
        q=q//2
        k+=1
    x=pow(a,q,n)
    if x==1 or n-1:return 'prob'
    elsE:
        while i in range(k-1)
            x=pow(x,2,n)
            if x==1 :
                return "comp"
            if x==n-1:
                return "prob"
        return "comp"
Alpha="ABC.....Z
def clean(X):
    return X.upper().replace(" ","")
def caeas(x,key,mode):
    a=""
    for ch in x:
        i=Alpha.index(ch)
        v=(key*mode+i)%26
        a+=Alpha[v]
    return a
def monoalphabetic(x,key):
    a=""
    for ch in x:
        i=Alpha.index(ch)
        a+=key[i]
    return a
def monoalp(x,key):
    a="
    for ch in x:
        i=key.index(ch)
        a+=A[i]
    return a
def inc_len(vig,pt):
    a=vig
    while i in range(len(pt)-len(vig)):
        a+=vig[i%len(vig)]
    return a
def vigenere(vig,pt):
    if..
    b=inc...

    for i in range(len(pt)):
        ind1=alp.idmex(vig[i])
        ind2= alpha.index(pt[i])
        v=(ind1*mode+ind2+26)%26
        r+=alpah[v]
def mk_mtrix(key):
    matrix=""
    r=(key+Alpha).replace("i","j")
    for ch in r:
        if ch in matrix:
            continue
        matrix+=ch
    matrix=np.array(list(s)).reshape(5,5)
    return matrix
def playfair(key,pt):
    matrix=mkl_martix(key)
    pt=pt.replace("i","j")
    
    while i <len(pt)
        a=pt[i]
        if pt[i]==pt[i+1] or i == len(pt)-1:
            b="x"
            i+=1
        
        esle:
            b=pt[i+1]
            i+=2

        pairs.append(a+b)
    result =""
    for pair in pairs:
        a,b=pair
        for i in rnag(5):
            for j inr nage(5):
                if matrix[i][j]==a:
                    r1,c1=i,j
                if matrix[i][j]==b:
                    r2,c2=i,j

        if r1 == r2:
            result+=matrix[r1][(c1+mode)%5]
            result+=matrix[r2][(c2+mode)%5]
        else if c1 == c2:
            result+=matrix[r1][(c1+mode)%5]
            result+=matrix[r2][(c2+mode)%5]
        else:
            reuslt+matrix[r1][c2]
            reuslt+matrix[r2][c1]
        retuls reuslt

def gen_key(text):
    text=text.upper().replace(" ","")
    key=[Alpha.index(x) for x in text]
    return np.array(key).reshape(3,3)

def inv_key(key):
    det=np.linalg.det(key) % 26
    inv=pow(det,-1,26)
    adj=np.rint()

def rail_fence(key,text):
    rails=[""]*key
    row=0
    dire=1
    for c in text:
        rails[row]+=c
        if row == 0:
            direction =1
        if row == key-1:
            direciotn=-1
        row+=dire
    return "".join(rails)
def rail_fence_d(key,text)
    rails=[[""] *len(text) for i in range(key)]
    row=0
    dire=1
    for i in range(len(text)):
        rails[row][i] ="*"
        if row==0:
            dir=1
        elif row == key-1:
            dir=-1
        row+=dir
    k=0
    for i in range(key):
        for j in range(len(text)):
            if rails[i][j] == "*":
                rails[i][j] =text[k]
                k+=1
    result = ""
    row=0
    dir=1
    for i in range(len(text)):
        result+=rails[row][i]
        if row==0:
            dir=1
        elif row == key-1:
            dir=-1
        row+=dir

def vernam(text,key,mode):
    c+=""
    if mode==1:
        for i in range(len(text))
            c+ chr(ord(text[i])^ord(key[i]))
    if mo=..
            c+ bin(int(text,2)^int(key,2))[:2]
def ge_enc()