import random

def gen_public(g, priv, p):
    return pow(g, priv, p)

def shared_secret(other_pub, priv, p):
    return pow(other_pub, priv, p)

# ---- public parameters ----
p = 23
g = 5

# ---- private keys (for exam: random.seed(int(UID)) before these) ----
a = random.randint(2, p - 2)   # Alice
b = random.randint(2, p - 2)   # Bob

# ---- exchange ----
A = gen_public(g, a, p)        # Alice sends A
B = gen_public(g, b, p)        # Bob sends B

K_alice = shared_secret(B, a, p)
K_bob   = shared_secret(A, b, p)

print("p, g      :", p, g)
print("Alice priv:", a, " public A:", A)
print("Bob priv  :", b, " public B:", B)
print("Alice key :", K_alice)
print("Bob key   :", K_bob)
print("Match     :", K_alice == K_bob)