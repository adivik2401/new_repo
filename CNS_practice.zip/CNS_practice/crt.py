def crt(a,m):
    M=1
    for i in m:
        M*=m
    x=0
    for i in range(lex(x)):
        Mi=M//m
        inv=pow(Mi,-1,m[i])
        x+=a[i]*Mi*inv
    return x%M
    