import numpy as np

def vernam(p,k,mode,operation):
    if modee =="ascii":
        p= np.frombuffer(p.encode(),dtpe=np.uint8)