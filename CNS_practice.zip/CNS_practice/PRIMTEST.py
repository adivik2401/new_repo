def fermat(n, a):
    if pow(a, n - 1, n) == 1:
        return "Probably prime"
    return "Composite"

def euler(n, a):
    r = pow(a, (n - 1) // 2, n)
    if r == 1 or r == n - 1:
        return "Probably prime"
    return "Composite"

def miller_rabin(n, a):
    s, d = 0, n - 1
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return "Probably prime"
    for i in range(s - 1):
        x = pow(x, 2, n)
        if x == n - 1:
            return "Probably prime"
        if x == 1:
            return "Composite"
    return "Composite"

print("fermat",fermat(341,2))
print("euler",euler(341,2))
print("miller_rabin",miller_rabin(341,2))