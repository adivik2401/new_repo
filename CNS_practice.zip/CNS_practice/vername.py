def vername(text,key,mode):
    
    if mode==0:# ascii
        c=""
        for i in range(len(text)):
            c+=chr(ord(key[i])^ord(text[i]))
        return c
    if mode==1: #bin
        C=bin(int(key,2)^int(text,2))[2:] #FULL not char wise
        return C
    if mode ==2:
        C=hex(int(text,16)^int(key,16))[2:] # 2 as wwedont ened the 0b at the start.
        return C
print([ord(ch) for ch in vername("ABC","XYZ",0)])