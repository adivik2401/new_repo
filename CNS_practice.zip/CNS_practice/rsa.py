n= p*q
phi=p-1*q-1

def rsa_enc(m,e,n):
    return pow(m,e,n)
def dec(m,d,b):
    return pow(m,d,n)
e=7
for i in range(2,phi):
    if gcd(i,phi) == 1:
        d= pow(e,-1,phi)
        break
c=rsa_enc   
