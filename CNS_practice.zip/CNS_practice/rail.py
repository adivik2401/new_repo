
def encrypt(plain,key):
    rail = []
    for i in range(key):
        rail.append([])
    dir = 1
    index=0 
    for l in range(len(plain)):
        char = plain[l]
        if(index==0 or index==key-1):
            dir = 1-dir  
        rail[index].append(char)
        if(dir==0):
            index+=1
        else:
            index-=1
    return rail 
# print(encrypt("HELLO",3))
matrix = encrypt("HELLO",3)
cipher=""
print(matrix)


        
def decrpt(ct,key):
    rail=[""]*key
    row=0
    dir=1

    for col in range(len(text)):
        rail[row][col]="*"
        if row==0:
            dir=1
        elif row==len(key)-1:
            dir=-1
        row+=dir
    index=0
    for i in range(key):
        for j in range(len(text)):
            if rail[i][j]=="*":
                rail[i][j]=text[index]
                index+=1
    result=""
    row=0
    dir=1
    for col in range(len(text)):
        rail[row][col]="*"
        if row==0:
            dir=1
        elif row==len(key)-1:
            dir=-1
        row+=dir
    return result