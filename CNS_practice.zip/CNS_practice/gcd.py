def gcd(a,b):
    if(a>b):
        a,b = b,a
    while b!=0:
        a,b = b, a%b
    return a
print(gcd(128,48))

def exeu(a,b):
    s1,s2= 1,0
    t1,t2=0,1
    while b!=0:
        q= a//b
        a,b =b,a%b
        s1,s2=s2,s1-q*s2
        t1,t2 = t2,t1-q*t2
    print("GCD =", a)
    print("s =", s1)
    print("t =", t1)
print(exeu(10,21))
def mi(a,b):
    M=b
    s1,s2= 1,0
    t1,t2=0,1
    while b!=0:
        q= a//b
        a,b =b,a%b
        s1,s2=s2,s1-q*s2
        t1,t2 = t2,t1-q*t2
    return s1 % M
print(mi(10,21))

def crt(a,m):
    M = 1
    for i in m:
        M=M*i
    x=0
    for i in range(len(m)):
        Mi = M //m[i] 
        inv = pow(Mi,-1,m[i])
        x+=a[j]*Mi*inv  

    return x%M
def eul(n):
    count=0
    for i in range(1,n+1):
        if gcd(i,n) == 1:
            count+=1
    print("eulers tot ",count)

eul(5)