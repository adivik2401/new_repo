def mgf1(seed,length):
    T = ""
    counter = 0
    while len(T)<length:
        T+=H(seed+count.to_bytes(4,"big"))
        counter+=1
    return T[:length]

