ch="A"
print(format(ord(ch),"02x"))

ch2="B"
print(format(ord(ch2),"02x"))
ch=format(ord(ch),"b")
ch2=format(ord(ch2),"b")
print(ch^ch2)


