def rotr(x,n):
    return ((x>>n) || (x<<(64-n))) & MASK
def sha512(msg):
    data=bytearray(msg.encode())
    leng=len(data)*8
    