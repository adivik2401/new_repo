
import random

random.seed(int(input("Enter UID: ")))

p = 23
g = 5

# Key Generation
x = random.randint(2, p - 2)
y = pow(g, x, p)

print("Public Key:", (p, g, y))
print("Private Key:", x)

# Encryption
m = int(input("Enter message: "))

k = random.randint(1, p - 2)

c1 = pow(g, k, p)
s = pow(y, k, p)
c2 = (m * s) % p

print("Ephemeral Key:", k)
print("Ciphertext:", (c1, c2))

# Decryption
s = pow(c1, x, p)
s_inv = pow(s, -1, p)

decrypted = (c2 * s_inv) % p

print("Decrypted Message:", decrypted)
