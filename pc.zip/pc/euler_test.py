import math

n = int(input("Enter number: "))
a = 2

if n <= 2 or n % 2 == 0:
    print("Not suitable for this test")
elif math.gcd(a, n) != 1:
    print("Composite")
else:
    x = pow(a, (n - 1) // 2, n)

    if x == 1 or x == n - 1:
        print("Probably Prime")
    else:
        print("Composite")