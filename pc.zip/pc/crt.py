
import math

n = int(input("Enter number of equations: "))

a = []
m = []

for i in range(n):
    x = int(input("Enter remainder: "))
    y = int(input("Enter modulus: "))

    a.append(x)
    m.append(y)

print("\nSTEP 1: INPUT CONGRUENCES")

for i in range(n):
    print("x =", a[i], "mod", m[i])

M = math.prod(m)

print("\nSTEP 2: PRODUCT OF MODULI")
print("M =", M)

result = 0

print("\nSTEP 3: CALCULATING PARTIAL PRODUCTS")

for i in range(n):

    Mi = M // m[i]

    print("\nM", i+1, "=", Mi)

    Mi_inv = pow(Mi, -1, m[i])

    print("Inverse of", Mi, "mod", m[i], "=", Mi_inv)

    term = a[i] * Mi * Mi_inv

    print("Term =", a[i], "*", Mi, "*", Mi_inv)
    print("Term =", term)

    result += term

print("\nSTEP 4: FINAL RESULT")

x = result % M

print("x =", result, "mod", M)
print("Final answer:", x)
