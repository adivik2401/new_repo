import math

key = [
    [17, 17, 5],
    [21, 18, 21],
    [2, 2, 19]
]
MOD = 26

print("KEY MATRIX:")
for row in key:
    print(row)

msg = input("\nEnter plaintext: ").upper().replace(" ", "")
while len(msg) % 3 != 0:
    msg += 'X'

# Determinant of 3x3 matrix
def determinant(M):
    return (M[0][0]*(M[1][1]*M[2][2] - M[1][2]*M[2][1])
            - M[0][1]*(M[1][0]*M[2][2] - M[1][2]*M[2][0])
            + M[0][2]*(M[1][0]*M[2][1] - M[1][1]*M[2][0]))

# Encryption
enc = ""
for i in range(0, len(msg), 3):
    p = [ord(msg[i])-65, ord(msg[i+1])-65, ord(msg[i+2])-65]
    c = []
    for r in range(3):
        value = 0
        for j in range(3):
            value += key[r][j] * p[j]
        c.append(value % 26)
    for value in c:
        enc += chr(value + 65)

print("Encrypted Text:", enc)

# Find inverse key matrix
det = determinant(key)
if math.gcd(det, 26) != 1:
    print("Inverse does not exist!")
    exit()

det_inv = pow(det % 26, -1, 26)
cof = []
for i in range(3):
    row = []
    for j in range(3):
        minor = []
        for x in range(3):
            if x != i:
                r = []
                for y in range(3):
                    if y != j:
                        r.append(key[x][y])
                minor.append(r)
        value = minor[0][0]*minor[1][1] - minor[0][1]*minor[1][0]
        row.append(((-1)**(i+j)) * value)
    cof.append(row)

# Adjoint is transpose of cofactor matrix
adj = [[cof[j][i] for j in range(3)] for i in range(3)]
key_inv = [[(det_inv * adj[i][j]) % 26 for j in range(3)] for i in range(3)]

print("Inverse Key Matrix:")
for row in key_inv:
    print(row)

# Decryption
dec = ""
for i in range(0, len(enc), 3):
    c = [ord(enc[i])-65, ord(enc[i+1])-65, ord(enc[i+2])-65]
    p = []
    for r in range(3):
        value = 0
        for j in range(3):
            value += key_inv[r][j] * c[j]
        p.append(value % 26)
    for value in p:
        dec += chr(value + 65)

print("Decrypted Text:", dec)
