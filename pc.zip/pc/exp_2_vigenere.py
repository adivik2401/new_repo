
uid = input("Enter UID: ")

key = ""

for i in range(0, len(uid), 2):
    num = int(uid[i:i+2])
    key += chr((num % 26) + 65)

print("Generated Key:", key)

msg = input("Enter plaintext: ").upper()

enc = ""
j = 0

for ch in msg:
    if ch >= 'A' and ch <= 'Z':
        p = ord(ch) - 65
        k = ord(key[j % len(key)]) - 65

        c = (p + k) % 26
        enc += chr(c + 65)

        j += 1
    else:
        enc += ch

print("Encrypted:", enc)

dec = ""
j = 0

for ch in enc:
    if ch >= 'A' and ch <= 'Z':
        c = ord(ch) - 65
        k = ord(key[j % len(key)]) - 65

        p = (c - k) % 26
        dec += chr(p + 65)

        j += 1
    else:
        dec += ch

print("Decrypted:", dec)
