import random

random.seed(int(input("Enter UID: ")))

# Public values
p = 29
g = 4

# Private keys
a = random.randint(2, p - 2)
b = random.randint(2, p - 2)

# Public keys
A = pow(g, a, p)
B = pow(g, b, p)

print("Alice Private Key:", a)
print("Bob Private Key:", b)
print("Alice Public Key:", A)
print("Bob Public Key:", B)

# Shared secret keys
key1 = pow(B, a, p)
key2 = pow(A, b, p)

print("Alice Shared Key:", key1)
print("Bob Shared Key:", key2)

if key1 == key2:
    print("Shared Key Established")
else:
    print("Key Exchange Failed")
