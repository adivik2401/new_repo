import random

n = int(input("Enter number: "))

a = random.randint(2, n-2)

r = pow(a, n-1, n)

if r == 1:
    print("Probably Prime")
else:
    print("Composite")