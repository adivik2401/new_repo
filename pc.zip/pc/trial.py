import random

random.seed(10)
print(random.randint(1, 100))  # Same output every run

random.seed(10)
print(random.randint(1, 100))  # Same output again