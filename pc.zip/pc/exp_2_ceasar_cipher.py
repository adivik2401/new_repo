uid = input("Enter UID: ")

key = (sum(int(i) for i in uid) % 25) + 1

print("Caesar Key:", key)

msg = input("Enter plaintext: ")

enc = ""

for ch in msg:
    if ch.isupper():
        enc += chr((ord(ch) - 65 + key) % 26 + 65)
    elif ch.islower():
        enc += chr((ord(ch) - 97 + key) % 26 + 97)
    else:
        enc += ch

print("Encrypted:", enc)

dec = ""

for ch in enc:
    if ch.isupper():
        dec += chr((ord(ch) - 65 - key) % 26 + 65)
    elif ch.islower():
        dec += chr((ord(ch) - 97 - key) % 26 + 97)
    else:
        dec += ch

print("Decrypted:", dec)