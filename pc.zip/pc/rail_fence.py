# Rail Fence Cipher - Encryption and Decryption

def encrypt(key, text):
    if key == 1:
        return text

    rails = [""] * key
    row = 0
    dire = 1

    for ch in text:
        rails[row] += ch

        if row == 0:
            dire = 1
        elif row == key - 1:
            dire = -1

        row += dire

    return "".join(rails)


def decrypt(key, text):
    if key == 1:
        return text

    rails = [[""] * len(text) for i in range(key)]
    row = 0
    dire = 1

    # Mark the zigzag positions
    for i in range(len(text)):
        rails[row][i] = "*"

        if row == 0:
            dire = 1
        elif row == key - 1:
            dire = -1

        row += dire

    # Fill the marked positions row by row
    k = 0
    for i in range(key):
        for j in range(len(text)):
            if rails[i][j] == "*":
                rails[i][j] = text[k]
                k += 1

    # Read the letters in zigzag order
    result = ""
    row = 0
    dire = 1

    for i in range(len(text)):
        result += rails[row][i]

        if row == 0:
            dire = 1
        elif row == key - 1:
            dire = -1

        row += dire

    return result


text = input("Enter plaintext: ")
key = int(input("Enter key: "))

cipher = encrypt(key, text)
print("Encrypted:", cipher)
print("Decrypted:", decrypt(key, cipher))
