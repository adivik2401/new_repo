import random
import string

uid = int(input("Enter UID: "))

random.seed(uid)

plain = string.ascii_uppercase
key = list(plain)

random.shuffle(key)
key = ''.join(key)

print("Substitution Key:", key)

msg = input("Enter plaintext: ").upper()

enc = ""

for ch in msg:
    if ch in plain:
        enc += key[plain.index(ch)]
    else:
        enc += ch

print("Encrypted:", enc)

dec = ""

for ch in enc:
    if ch in key:
        dec += plain[key.index(ch)]
    else:
        dec += ch

print("Decrypted:", dec)