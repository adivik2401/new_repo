uid = input("Enter UID: ")

key = ""

for i in range(0, len(uid), 2):
    num = int(uid[i:i+2])
    key += chr((num % 26) + 65)

print("Generated Key:", key)

key = key.replace("J", "I")
matrix = ""

for ch in key + "ABCDEFGHIKLMNOPQRSTUVWXYZ":
    if ch not in matrix:
        matrix += ch

matrix = [matrix[i:i+5] for i in range(0, 25, 5)]

print("Key Matrix:")

for row in matrix:
    print(row)

msg = input("Enter plaintext: ").upper().replace("J", "I")
msg = "".join(ch for ch in msg if ch.isalpha())
# ingnores everything except alphabets

pairs = []
i = 0

while i < len(msg):
    a = msg[i]

    if i + 1 == len(msg):
        b = 'X'
        i += 1
    elif msg[i] == msg[i+1]:
        b = 'X'
        i += 1
    else:
        b = msg[i+1]
        i += 2

    pairs.append(a + b)

def encrypt(a, b):
    r1 = c1 = r2 = c2 = 0

    for r in range(5):
        for c in range(5):
            if matrix[r][c] == a:
                r1, c1 = r, c
            if matrix[r][c] == b:
                r2, c2 = r, c

    if r1 == r2:
        return matrix[r1][(c1+1)%5] + matrix[r2][(c2+1)%5]
    elif c1 == c2:
        return matrix[(r1+1)%5][c1] + matrix[(r2+1)%5][c2]
    else:
        return matrix[r1][c2] + matrix[r2][c1]

def decrypt(a, b):
    r1 = c1 = r2 = c2 = 0

    for r in range(5):
        for c in range(5):
            if matrix[r][c] == a:
                r1, c1 = r, c
            if matrix[r][c] == b:
                r2, c2 = r, c

    if r1 == r2:
        return matrix[r1][(c1-1)%5] + matrix[r2][(c2-1)%5]
    elif c1 == c2:
        return matrix[(r1-1)%5][c1] + matrix[(r2-1)%5][c2]
    else:
        return matrix[r1][c2] + matrix[r2][c1]

enc = ""

for pair in pairs:
    enc += encrypt(pair[0], pair[1])

print("Encrypted:", enc)

dec = ""

for i in range(0, len(enc), 2):
    dec += decrypt(enc[i], enc[i+1])

print("Decrypted:", dec)
