import random

def is_prime(n, k=5):
    # Handle small base cases
    if n < 2:
        return "Composite"
    if n in (2, 3):
        return "Probably Prime"
    if n % 2 == 0:
        return "Composite"

    # Factor out powers of 2 from n - 1
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    # Witness loop
    for _ in range(k):
        # Safe range choice for all n > 3
        a = random.randint(2, n - 2)
        x = pow(a, d, n)

        if x == 1 or x == n - 1:
            continue

        for _ in range(s - 1):
            x = pow(x, 2, n)  # Using built-in pow is faster than (x * x) % n
            if x == n - 1:
                break
        else:
            # Hitting 1 or finishing without finding n-1 means it's composite
            return "Composite"

    return "Probably Prime"

# Example execution
num = int(input("Enter number: "))
print(is_prime(num))
