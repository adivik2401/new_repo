
import random

UID = int(input("Enter UID: "))
random.seed(UID)

# Curve Parameters
p = 17
a = 2
b = 2

# Base Point
G = (5, 1)

# Point Addition
def point_add(P, Q):
    if P is None:
        return Q

    if Q is None:
        return P

    x1, y1 = P
    x2, y2 = Q

    if x1 == x2 and (y1 + y2) % p == 0:
        return None

    if P == Q:
        num = 3 * x1 * x1 + a
        den = 2 * y1
    else:
        num = y2 - y1
        den = x2 - x1

    lam = (num * pow(den % p, -1, p)) % p

    x3 = (lam * lam - x1 - x2) % p
    y3 = (lam * (x1 - x3) - y1) % p

    return (x3, y3)


# Scalar Multiplication
def scalar_mult(k, P):
    result = None

    for i in range(k):
        result = point_add(result, P)

    return result


# Key Generation
private_key = random.randint(1, 18)

public_key = scalar_mult(private_key, G)

# ECC Operation
result = scalar_mult(private_key, G)

print("\nECC Parameters")
print("Curve: y^2 = x^3 +", a, "x +", b, "mod", p)
print("Base Point G:", G)
print("Private Key:", private_key)
print("Public Key:", public_key)
print("Result:", result)
