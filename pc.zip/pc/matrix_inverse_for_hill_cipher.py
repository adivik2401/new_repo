
import math

K = [
    [17, 17, 5],
    [21, 18, 21],
    [2, 2, 19]
]

MOD = 26

def determinant(M):
    return (
        M[0][0] * (M[1][1]*M[2][2] - M[1][2]*M[2][1])
        - M[0][1] * (M[1][0]*M[2][2] - M[1][2]*M[2][0])
        + M[0][2] * (M[1][0]*M[2][1] - M[1][1]*M[2][0])
    )

def print_matrix(M):
    for row in M:
        print(row)

def mod_inverse(a, m):
    t1, t2 = 0, 1
    r1, r2 = m, a

    print("\nExtended Euclidean Algorithm:")
    print("q\t r1\t r2\t r\t t1\t t2\t t")

    while r2 != 0:
        q = r1 // r2
        r = r1 - q * r2
        t = t1 - q * t2

        print(q, "\t", r1, "\t", r2, "\t", r,
              "\t", t1, "\t", t2, "\t", t)

        r1, r2 = r2, r
        t1, t2 = t2, t

    if r1 != 1:
        return None

    return t1 % m

print("ORIGINAL MATRIX:")
print_matrix(K)

# Step 1: Determinant
det = determinant(K)

print("\nSTEP 1: DETERMINANT")
print("Determinant =", det)
print("Determinant mod 26 =", det % MOD)

d = det % MOD

# Step 2: GCD
print("\nSTEP 2: CHECK GCD")
print("GCD(", d, ", 26 ) =", math.gcd(d, MOD))

if math.gcd(d, MOD) != 1:
    print("Inverse does not exist!")
    exit()

# Step 3: EEA
print("\nSTEP 3: MODULAR INVERSE OF DETERMINANT")

inv_det = mod_inverse(d, MOD)

print("\nDeterminant inverse =", inv_det)

# Step 4: Minors and Cofactors
print("\nSTEP 4: MINORS AND COFACTORS")

cofactor = []

for i in range(3):
    row = []
    for j in range(3):
        minor = []

        for x in range(3):
            if x != i:
                r = []
                for y in range(3):
                    if y != j:
                        r.append(K[x][y])
                minor.append(r)

        value = (
            minor[0][0] * minor[1][1]
            - minor[0][1] * minor[1][0]
        )

        sign = (-1) ** (i + j)
        cof = sign * value

        print("Element", (i+1, j+1),
              "Minor =", value,
              "Cofactor =", cof)

        row.append(cof)

    cofactor.append(row)

print("\nCOFACTOR MATRIX:")
print_matrix(cofactor)

# Step 5: Adjoint
print("\nSTEP 5: ADJOINT MATRIX")

adj = [[cofactor[j][i] for j in range(3)] for i in range(3)]

print_matrix(adj)

adj_mod = [[x % MOD for x in row] for row in adj]

print("\nADJOINT MOD 26:")
print_matrix(adj_mod)

# Step 6: Final inverse
print("\nSTEP 6: MULTIPLY BY MODULAR INVERSE")

print("Inverse = ", inv_det, "x Adjoint (mod 26)")

inverse = [
    [(inv_det * adj_mod[i][j]) % MOD for j in range(3)]
    for i in range(3)
]

print("\nFINAL INVERSE MATRIX:")
print_matrix(inverse)

# Step 7: Verification
print("\nSTEP 7: VERIFICATION")

product = [
    [
        sum(K[i][k] * inverse[k][j] for k in range(3)) % MOD
        for j in range(3)
    ]
    for i in range(3)
]

print("K x K_inverse mod 26:")
print_matrix(product)

if product == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]:
    print("\nVERIFICATION SUCCESSFUL!")
else:
    print("\nVERIFICATION FAILED!")
