
import random
import math

random.seed(int(input("Enter UID: ")))

def is_prime(n):
    if n < 2:
        return False

    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False

    return True

def generate_prime():
    while True:
        n = random.randint(50, 100)
        if is_prime(n):
            return n

p = generate_prime()
q = generate_prime()

while p == q:
    q = generate_prime()

n = p * q
phi = (p - 1) * (q - 1)

e = 3
while math.gcd(e, phi) != 1:
    e += 2

d = pow(e, -1, phi)

print("p =", p)
print("q =", q)
print("n =", n)
print("phi =", phi)
print("Public Key =", (e, n))
print("Private Key =", (d, n))

m = int(input("Enter message (number): "))

c = pow(m, e, n)
print("Encrypted Message =", c)

decrypted = pow(c, d, n)
print("Decrypted Message =", decrypted)
