import hashlib
import random
import math

# RSA-PSS using SHA-256 and an 8-byte salt
# Educational implementation only: random is NOT cryptographically secure.

def is_prime(n):
    if n < 2:
        return False

    for p in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]:
        if n % p == 0:
            return n == p

    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    for i in range(20):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)

        if x == 1 or x == n - 1:
            continue

        for j in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False

    return True


def gen_prime(bits):
    while True:
        n = random.getrandbits(bits)
        n = n | (1 << (bits - 1)) | 1
        if is_prime(n):
            return n


# Generate RSA keys (may take a few seconds)
e = 65537
p = gen_prime(512)
q = gen_prime(512)
while q == p:
    q = gen_prime(512)

n = p * q
phi = (p - 1) * (q - 1)
while math.gcd(e, phi) != 1:
    q = gen_prime(512)
    phi = (p - 1) * (q - 1)

d = pow(e, -1, phi)


def H(data):
    return hashlib.sha256(data).digest()


def MGF1(seed, length):
    result = b""
    for i in range((length + 31) // 32):
        result += H(seed + i.to_bytes(4, "big"))
    return result[:length]


def encode(message, em_bits):
    m_hash = H(message)
    salt = random.randbytes(8)
    h = H(b"\x00" * 8 + m_hash + salt)

    em_len = (em_bits + 7) // 8
    db_len = em_len - 32 - 1
    ps_len = em_len - 32 - 8 - 2

    db = b"\x00" * ps_len + b"\x01" + salt
    mask = MGF1(h, db_len)
    masked_db = bytes(a ^ b for a, b in zip(db, mask))

    unused = 8 * em_len - em_bits
    if unused:
        masked_db = bytes([masked_db[0] & (255 >> unused)]) + masked_db[1:]

    return masked_db + h + b"\xbc"


def sign(message):
    em_bits = n.bit_length() - 1
    em = encode(message, em_bits)
    m = int.from_bytes(em, "big")
    return pow(m, d, n)


def verify(message, signature):
    if signature < 0 or signature >= n:
        return False

    em_bits = n.bit_length() - 1
    em_len = (em_bits + 7) // 8
    m = pow(signature, e, n)
    em = m.to_bytes(em_len, "big")

    masked_db = em[:-33]
    h = em[-33:-1]
    if em[-1] != 0xbc:
        return False

    unused = 8 * em_len - em_bits
    if unused and (masked_db[0] >> (8 - unused)) != 0:
        return False

    mask = MGF1(h, len(masked_db))
    db = bytes(a ^ b for a, b in zip(masked_db, mask))

    if unused:
        db = bytes([db[0] & (255 >> unused)]) + db[1:]

    ps_len = em_len - 32 - 8 - 2
    if db[:ps_len] != b"\x00" * ps_len or db[ps_len] != 1:
        return False

    salt = db[-8:]
    h2 = H(b"\x00" * 8 + H(message) + salt)
    return h == h2


# Main program
message = input("Enter message: ").encode()
signature = sign(message)

print("Signature:", signature)
print("Verification:", verify(message, signature))
print("Verification with changed message:", verify(message + b"x", signature))
