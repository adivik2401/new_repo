import math

key = [[3, 3], [2, 5]]
MOD = 26

print("KEY MATRIX:")
for row in key:
    print(row)

msg = input("\nEnter plaintext: ").upper().replace(" ", "")
if len(msg) % 2 != 0:
    msg += 'X'

# Encryption
enc = ""
for i in range(0, len(msg), 2):
    p = [ord(msg[i]) - 65, ord(msg[i+1]) - 65]
    c = [
        (key[0][0]*p[0] + key[0][1]*p[1]) % 26,
        (key[1][0]*p[0] + key[1][1]*p[1]) % 26
    ]
    enc += chr(c[0] + 65) + chr(c[1] + 65)

print("Encrypted Text:", enc)

# Find inverse key matrix
det = key[0][0]*key[1][1] - key[0][1]*key[1][0]
if math.gcd(det, 26) != 1:
    print("Inverse does not exist!")
    exit()

det_inv = pow(det % 26, -1, 26)
adj = [[key[1][1], -key[0][1]], [-key[1][0], key[0][0]]]
key_inv = [[(det_inv * adj[i][j]) % 26 for j in range(2)] for i in range(2)]

print("Inverse Key Matrix:")
for row in key_inv:
    print(row)

# Decryption
dec = ""
for i in range(0, len(enc), 2):
    c = [ord(enc[i]) - 65, ord(enc[i+1]) - 65]
    p = [
        (key_inv[0][0]*c[0] + key_inv[0][1]*c[1]) % 26,
        (key_inv[1][0]*c[0] + key_inv[1][1]*c[1]) % 26
    ]
    dec += chr(p[0] + 65) + chr(p[1] + 65)

print("Decrypted Text:", dec)
