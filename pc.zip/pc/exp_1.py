a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

r1 = max(a, b)
r2 = min(a, b)

print("q\tr1\tr2\tr")

while r2 != 0:
    q = r1 // r2
    r = r1 % r2

    print(q, r1, r2, r, sep="\t")

    r1 = r2
    r2 = r

print("GCD =", r1)


a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

r1 = max(a, b)
r2 = min(a, b)

s1, s2 = 1, 0
t1, t2 = 0, 1

print("q\tr1\tr2\tr\ts1\ts2\ts\tt1\tt2\tt")

while r2 != 0:
    q = r1 // r2
    r = r1 % r2
    s = s1 - s2 * q
    t = t1 - t2 * q

    print(q, r1, r2, r, s1, s2, s, t1, t2, t, sep="\t")

    r1, r2 = r2, r
    s1, s2 = s2, s
    t1, t2 = t2, t

print("GCD =", r1)
print("s =", s1)
print("t =", t1)


a = int(input("Enter number: "))
n = int(input("Enter modulo: "))

r1 = n
r2 = a

t1, t2 = 0, 1

print("q\tr1\tr2\tr\tt1\tt2\tt")

while r2 != 0:
    q = r1 // r2
    r = r1 % r2
    t = t1 - t2 * q

    print(q, r1, r2, r, t1, t2, t, sep="\t")

    r1, r2 = r2, r
    t1, t2 = t2, t

print("GCD =", r1)

if r1 == 1:
    print("MI =", t1 % n)
else:
    print("Multiplicative Inverse does not exist")